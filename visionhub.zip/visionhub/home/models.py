# home/models.py
from django.db import models

class UploadedImage(models.Model):
    image = models.ImageField(upload_to='uploads/')
    detected_objects = models.TextField(blank=True)  # Store labels and confidence scores as text
    processed_image = models.ImageField(upload_to='results/', blank=True, null=True)
 