import os 
import torch
import torch.nn as nn
from torchvision import models, transforms
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from PIL import Image
from .models import UploadedImage
import pyttsx3
from django.conf import settings
from django.shortcuts import render, get_object_or_404
from .models import UploadedImage
from .forms import ImageUploadForm
from ultralytics import YOLO

# Initialize YOLO model
model = YOLO("yolo11n-seg.pt")  # load a pretrained model (recommended for training) 

 

def home(request):
    form = ImageUploadForm()
    uploaded_image = None
    processed_image = None
    detected_objects = None

    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_image = form.save()
            return render(request, 'home/home.html', {
                'form': form,
                'uploaded_image': uploaded_image,
                'processed_image': None,
                'detected_objects': None
            })
    
    return render(request, 'home/home.html', {
        'form': form,
        'uploaded_image': uploaded_image,
        'processed_image': processed_image,
        'detected_objects': detected_objects
    })


def detect(request, image_id):
    uploaded_image = get_object_or_404(UploadedImage, id=image_id)
    img_path = os.path.join(settings.MEDIA_ROOT, uploaded_image.image.name)

    # Run the YOLO model for object detection
    results = model(img_path)
 
    # Extract object names and confidence scores
    detected_objects = []
    person_detected = False 
    bird_detected = False
    
    for result in results:
        for box in result.boxes:
            class_name = model.names[int(box.cls)]
            confidence = box.conf.item()
            detected_objects.append(f"{class_name} ({confidence:.2f})")
            if class_name == "person":
                person_detected = True
            elif class_name == "bird":
                bird_detected = True

    detected_objects_text = ", ".join(detected_objects)

    # Ensure the results directory exists
    results_dir = os.path.join(settings.MEDIA_ROOT, 'results')
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    # Save the processed image
    result_image_path = os.path.join(results_dir, os.path.basename(uploaded_image.image.name))
    results[0].save(result_image_path)

    # Save paths in the uploaded_image instance
    uploaded_image.processed_image = result_image_path.replace('\\', '/')  # Normalize path for URLs
    uploaded_image.detected_objects = detected_objects_text
    uploaded_image.save()

    # Voice Assistant to speak the detected objects
    engine = pyttsx3.init()
    engine.say(f"Birdie, we detect {detected_objects_text} in the image.")
    engine.runAndWait()

    return render(request, 'home/home.html', {
        'form': ImageUploadForm(), 
        'uploaded_image': uploaded_image,
        'processed_image': uploaded_image.processed_image,
        'detected_objects': uploaded_image.detected_objects,
        'person_detected': person_detected,      
        'bird_detected': bird_detected,
    })
