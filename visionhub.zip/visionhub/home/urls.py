from django.urls import path
from . import views
from cls.views import bird_view
from face.views import person_view


urlpatterns = [
    path('', views.home, name='home'), 
       path('detect/<int:image_id>/', views.detect, name='detect'),
         path('person/', person_view, name='person'),  # New view for person
     path('bird/', bird_view, name='bird'), 
      
   
]
