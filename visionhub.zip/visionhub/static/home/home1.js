
    const fileInput = document.getElementById('file-upload');
    const previewArea = document.getElementById('preview-area');
    const previewMedia = document.getElementById('preview-media');

    fileInput.addEventListener('change', function () {
        const file = this.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            previewArea.style.display = 'block';
            if (file.type.startsWith('image')) {
                previewMedia.innerHTML = `<img src="${e.target.result}" alt="Preview" width="300px">`;
            } else if (file.type.startsWith('video')) {
                previewMedia.innerHTML = `<video width="300" controls><source src="${e.target.result}"></video>`;
            }
        };
        reader.readAsDataURL(file);
    });

    function removePreview() {
        fileInput.value = "";
        previewArea.style.display = 'none';
        previewMedia.innerHTML = "";
    }

    function resetAll() {
        removePreview();

        // Reset only the upload form
        const uploadForm = document.querySelector('#upload_content form');
        if (uploadForm) uploadForm.reset();

        // Optionally, clear uploaded image section if dynamically inserted
        const uploadedImage = document.querySelector("#upload_content img");
        if (uploadedImage) uploadedImage.remove();

        // Optionally, hide detect button section
        const detectSection = document.getElementById("detect_button_section");
        if (detectSection) detectSection.style.display = "none";

        // Optionally, clear results section
        const resultContent = document.getElementById("result_content");
        if (resultContent) resultContent.innerHTML = "";
    }
