import os
import cv2
import face_recognition
import pyttsx3
from django.shortcuts import render
from django.conf import settings        
from home.models import UploadedImage

# Function to detect and annotate faces
def detect_faces(image_path, face_name):
    img = cv2.imread(image_path)
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    face_locations = face_recognition.face_locations(rgb_img)
 
    for (top, right, bottom, left) in face_locations:
        cv2.rectangle(img, (left, top), (right, bottom), (0, 0, 255), 3)
        cv2.putText(img, face_name or "Unknown", (left, top - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255 , 0), 4)

    # Save annotated image (optional)
    detected_image_path = os.path.join(settings.MEDIA_ROOT, 'detected_faces.jpg')
    cv2.imwrite(detected_image_path, img)

    return detected_image_path, face_locations




def recognize_face(image_path):
    known_face_names = ['Megan Fox', 'Natalie Portman', 'Robert Downey Jr', 'Scarlett Johansson', 'Tom Cruise']
    known_face_encodings = []

    for name in known_face_names:
        # Build the path to the image in subfolder
        person_folder = os.path.join('images', name)
        
        # Attempt to load any image from this folder
        try:
            # Find the first image file in the subfolder
            files = os.listdir(person_folder)
            image_files = [f for f in files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            if not image_files:
                print(f"No image files found for {name}")
                continue

            image_path_known = os.path.join(person_folder, image_files[0])
            known_image = face_recognition.load_image_file(image_path_known)
            encoding = face_recognition.face_encodings(known_image)

            if encoding:
                known_face_encodings.append(encoding[0])
            else:
                print(f"No face found in known image for {name}")

        except FileNotFoundError:
            print(f"Image folder for {name} not found")
        except Exception as e:
            print(f"Error processing image for {name}: {e}")

    # Load and encode the unknown image
    unknown_image = face_recognition.load_image_file(image_path)
    unknown_encodings = face_recognition.face_encodings(unknown_image)

    if unknown_encodings:
        for encoding in unknown_encodings:
            results = face_recognition.compare_faces(known_face_encodings, encoding, tolerance=0.5)
            for i, match in enumerate(results):
                if match:
                    return known_face_names[i]

    return None


# Django view function
def person_view(request):
    uploaded_image = UploadedImage.objects.filter(detected_objects__icontains='person').order_by('-id').first()
    face_name = None
    detected_image_url = None

    if request.method == 'POST' and 'face_reco' in request.POST:
        if uploaded_image:
            image_path = os.path.join(settings.MEDIA_ROOT, uploaded_image.image.name)

            # Recognize face
            face_name = recognize_face(image_path)

            # Detect face and draw rectangle
            detected_image_path, faces = detect_faces(image_path, face_name)

            # Convert path to media URL
            detected_image_url = os.path.join(settings.MEDIA_URL, os.path.basename(detected_image_path))

            # Speak the result
            engine = pyttsx3.init()
            if face_name:
                response = f"Birdie, the face we detected is {face_name}"
            else:
                response = "No match found for the detected face."
            engine.say(response)
            engine.runAndWait()

    return render(request, 'home/person.html', {
        'uploaded_image': uploaded_image,
        'face_name': face_name,
        'detected_image_url': detected_image_url,
    })

                                              