import torch
import torch.nn as nn
from torchvision import models, transforms
from django.shortcuts import render, get_object_or_404
from PIL import Image
import os  
from django.conf import settings
from home.models import UploadedImage
import pyttsx3     

# Initialize your model architecture
model = models.resnet18()  
fc_in_features = model.fc.in_features
model.fc = nn.Linear(fc_in_features, 20)  

# Load the trained model weights
model.load_state_dict(torch.load('bird_resnet_classifier.pt', map_location=torch.device('cpu')))
model.eval()  
 
# Define your transforms 
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
     transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
   
])

# Define the class labels
label_map = {0: 'ABBOTTS BABBLER', 1: 'ABBOTTS BOOBY', 2: 'ABYSSINIAN GROUND HORNBILL', 3: 'AFRICAN CROWNED CRANE', 4: 'AFRICAN EMERALD CUCKOO', 5: 'AFRICAN FIREFINCH', 6: 'AFRICAN OYSTER CATCHER', 7: 'AFRICAN PIED HORNBILL', 8: 'AFRICAN PYGMY GOOSE', 9: 'ALBATROSS', 10: 'ALBERTS TOWHEE', 11: 'ALEXANDRINE PARAKEET', 12: 'ALPINE CHOUGH', 13: 'ALTAMIRA YELLOWTHROAT', 14: 'AMERICAN AVOCET', 15: 'AMERICAN BITTERN', 16: 'AMERICAN COOT', 17: 'AMERICAN FLAMINGO', 18: 'AMERICAN GOLDFINCH', 19: 'AMERICAN KESTREL'}

def classify_image(image_path):
    # Open the image
    image = Image.open(image_path).convert('RGB')
    
    # Apply the transforms
    image = transform(image)
    image = image.unsqueeze(0)
     
    # Make prediction
    with torch.no_grad():
        output = model(image)
        _, predicted_class = torch.max(output, 1)
    
    return label_map[predicted_class.item()]

def bird_view(request):
    uploaded_image = UploadedImage.objects.filter(detected_objects__icontains='bird').order_by('-id').first()
    classified_bird = None

    if request.method == 'POST' and 'classify' in request.POST:
        if uploaded_image:
            image_path = os.path.join(settings.MEDIA_ROOT, uploaded_image.image.name)
            classified_bird = classify_image(image_path)

            # Initialize the voice assistant
            engine = pyttsx3.init()
            # Create the response string
            response = f"There is birdie! The bird we detected is a {classified_bird}"
            # Use the engine to say the response
            engine.say(response)
            engine.runAndWait() 

    return render(request, 'home/bird.html', {
        'uploaded_image': uploaded_image,
        'classified_bird': classified_bird,
    })
 